package pages;

import org.openqa.selenium.WebElement;

import io.appium.java_client.android.AndroidDriver;
import pages.ObjectsUtils.ObjectUtils;

public class LoginByEmailPage {

	// objects

	public WebElement emailField = ObjectUtils.getElementById("co.oction:id/input_email");
	public WebElement passwordField = ObjectUtils.getElementById("co.oction:id/input_pass");
	public WebElement signinButton = ObjectUtils.getElementById("co.oction:id/btn_signin");

	// Actions
	public void login(String email, String password) throws InterruptedException {
		emailField.sendKeys(email);
		passwordField.sendKeys(password);
		Thread.sleep(1000);
		signinButton.click();
	}

}
