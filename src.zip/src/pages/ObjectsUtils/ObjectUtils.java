package pages.ObjectsUtils;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import FrameWork.DriverClass;
import io.appium.java_client.android.AndroidDriver;
public class ObjectUtils {

	public static WebElement getElementById(String id){
		return DriverClass.getDriver().findElement(By.id(id));
	}
	
	public static WebElement getElementByName( String name){
		return DriverClass.getDriver().findElement(By.name(name));
	}
	
	public static WebElement getElementByXpath(String xpath){
		
		return DriverClass.getDriver().findElement(By.xpath(xpath));
	}
	
	public static List<WebElement> getElementsByXpath(String xpath){
		return DriverClass.getDriver().findElements(By.xpath(xpath));
	}
	public static List<WebElement> getElementsById(String id){
		return DriverClass.getDriver().findElements(By.id(id));
	}
	
}
