package pages;

import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import pages.ObjectsUtils.ObjectUtils;

public class ShippingAddressPage {

	// Objects
	public WebElement addShippingAddressButton = ObjectUtils.getElementByXpath("//android.widget.TextView[@resource-id='co.oction:id/txtContactName' and @text='Add Shipping Address']");
	public List<WebElement> savedContactAddresses=ObjectUtils.getElementsById("co.oction:id/txtAddress");
	public List<WebElement> savedContactContactName=ObjectUtils.getElementsByXpath("//android.widget.TextView[@resource-id='co.oction:id/txtContactName' and @text!='Add Shipping Address']");
	
	public class EditOrCreteShippingAddressPage{
	public WebElement contactNameField = ObjectUtils.getElementById("co.oction:id/input_contact_name");
	public WebElement contactNumberField = ObjectUtils.getElementById("co.oction:id/input_contact_number");
	public WebElement AddressLineOneField = ObjectUtils.getElementById("co.oction:id/input_street_address");
	public WebElement AddressLineTwoField = ObjectUtils.getElementById("co.oction:id/input_street_address2");
	public WebElement saveButton = ObjectUtils.getElementById("co.oction:id/action_save_address");

	// Actions
	public void addShippingAddress(String contactName, String contactNumber, String addressLine1, String addressLine2)
			throws InterruptedException {

		contactNameField.sendKeys(contactName);
		contactNumberField.sendKeys(contactNumber);
		AddressLineOneField.sendKeys(addressLine1);
		AddressLineTwoField.sendKeys(addressLine2);
		Thread.sleep(1000);
	}

	public HashMap<String,String> getShippingAddressValues() {
		// TODO Auto-generated method stub
		HashMap<String,String> addressDetails=new HashMap<>();
		addressDetails.put("contactName", contactNameField.getText());
		addressDetails.put("contactNumber", contactNumberField.getText());
		addressDetails.put("addressLine1", AddressLineOneField.getText());
		addressDetails.put("addressLine2", AddressLineTwoField.getText());
		
		return addressDetails;
	}
	
	}

	public void validateSavedAddress(HashMap<String,String> addresses, int addressCount) {
		
		List<WebElement> savedContactAddressesAfterSave=ObjectUtils.getElementsById("co.oction:id/txtAddress");
		List<WebElement> savedContactContactNameAfterSave=ObjectUtils.getElementsByXpath("//android.widget.TextView[@resource-id='co.oction:id/txtContactName' and @text!='Add Shipping Address']");
		// TODO Auto-generated method stub
		if(savedContactAddressesAfterSave.size()==addressCount+1) {
			System.out.println("contacts count has increased by 1 upon save");
		}else {
			System.out.println("size before "+addressCount);
			System.out.println("size after "+savedContactAddresses.size());
			Assert.fail("Address count is not increased upon save, The address that you have entered might be invalid");
		}
		
		if(savedContactContactNameAfterSave.get(savedContactContactNameAfterSave.size()-1).getText().trim().equals(addresses.get("contactName")+" ("+addresses.get("contactNumber")+")")) {
			System.out.println("contact details are updated correctly");
		}else {
			Assert.fail("contact details are mismatching");
		}
		
		if(savedContactAddressesAfterSave.get(savedContactContactNameAfterSave.size()-1).getText().trim().split(",")[0].trim().equals(addresses.get("addressLine1"))) {
			System.out.println("address line 1 is updated correctly");
			if(savedContactAddressesAfterSave.get(savedContactContactNameAfterSave.size()-1).getText().trim().split(",")[1].trim().equals(addresses.get("addressLine2"))) {
				System.out.println("address line 2 is updated correctly");
			}
			else {
				Assert.fail("address line 2 is not updated correctly");
			}
		}else {
			Assert.fail("address line 1 is not updated correctly");
		}
	}


}
