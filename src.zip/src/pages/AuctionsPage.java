package pages;

import org.openqa.selenium.WebElement;

import io.appium.java_client.android.AndroidDriver;
import pages.ObjectsUtils.ObjectUtils;

public class AuctionsPage {

	// objects
	public WebElement accountsTab = ObjectUtils.getElementById("co.oction:id/tab_img_account");
}
