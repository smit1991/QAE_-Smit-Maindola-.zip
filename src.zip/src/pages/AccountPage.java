package pages;

import org.openqa.selenium.WebElement;

import io.appium.java_client.android.AndroidDriver;
import pages.ObjectsUtils.ObjectUtils;

public class AccountPage {

//objects
public WebElement shippingAddressTab=ObjectUtils.getElementById( "co.oction:id/btn_address");


}
