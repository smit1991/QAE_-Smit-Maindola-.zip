package pages;

import org.openqa.selenium.WebElement;

import io.appium.java_client.android.AndroidDriver;
import pages.ObjectsUtils.ObjectUtils;
public class StartPage{

//objects
public WebElement loginButton=ObjectUtils.getElementByXpath("//android.widget.Button[@index='1']");

}
