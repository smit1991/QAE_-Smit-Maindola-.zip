package FrameWork;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;


import io.appium.java_client.android.AndroidDriver;

public class DriverClass {

	private static AndroidDriver driver;
	
	public static AndroidDriver  getDriver() {
		return driver;
	}
	
	public static void setDriver(String url,DesiredCapabilities caps) throws MalformedURLException {
		driver = new AndroidDriver(new URL(url), caps);
	}
}
