package octionLogin;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import FrameWork.DriverClass;
import io.appium.java_client.android.AndroidDriver;
import pages.AccountPage;
import pages.AuctionsPage;
import pages.LoginByEmailPage;
import pages.LoginHomePage;
import pages.ShippingAddressPage;
import pages.ShippingAddressPage.EditOrCreteShippingAddressPage;
import pages.StartPage;

public class Appium {

	public static AndroidDriver driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		// Set the Desired Capabilities
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "Galaxy S8"); // My device Name
		caps.setCapability("udid", "98895a385a354c5a57"); // Give Device ID of your mobile phone
		caps.setCapability("platformName", "Android"); // Android OS
		caps.setCapability("platformVersion", "7.0"); // Android Version
		caps.setCapability("appPackage", "co.oction");
		caps.setCapability("appActivity", "co.oction.activities.LauncherActivity"); // Launcher Page of Oction
		// caps.setCapability("noReset", "true");

		// Instantiate Appium Driver
		DriverClass.setDriver("http://0.0.0.0:4723/wd/hub", caps);

		DriverClass.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// click on Login
		StartPage startPage = new StartPage();
		startPage.loginButton.click();
		Thread.sleep(5000);// wait for 5 sec

		// Click email option
		LoginHomePage loginHomePage = new LoginHomePage();
		loginHomePage.emailButton.click();
		Thread.sleep(5000);

		// enter details using scanner class
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter user name");
		String Email = sc.next();
		Thread.sleep(2);
		System.out.println("Enter password");
		String Password = sc.next();
		Thread.sleep(2);

		// enter email id, password and sign-in
		LoginByEmailPage loginByEmailPage = new LoginByEmailPage();
		loginByEmailPage.login(Email, Password);

		// click on accounts tab
		AuctionsPage auctionsPage = new AuctionsPage();
		auctionsPage.accountsTab.click();
		Thread.sleep(5000);

		// click on shipping address tab
		AccountPage accountPage = new AccountPage();
		accountPage.shippingAddressTab.click();

		// Add Shipping Address
		ShippingAddressPage shippingAddressPage = new ShippingAddressPage();
		shippingAddressPage.addShippingAddressButton.click();
		Thread.sleep(5000);
		ShippingAddressPage.EditOrCreteShippingAddressPage addShippingAddressPage= shippingAddressPage.new EditOrCreteShippingAddressPage();
		
		//getting the count of addresses before save
		int addressCountBeforeSave=shippingAddressPage.savedContactAddresses.size();
		
		addShippingAddressPage.addShippingAddress("smit", "100", "bellandur", "ecospace");
		
		//getting the address details before save
		HashMap<String,String> enteredAddressDetailsbeforeSave=addShippingAddressPage.getShippingAddressValues();
		//click save
		addShippingAddressPage.saveButton.click();
		Thread.sleep(3000);
		
		//Validating saved address
		shippingAddressPage.validateSavedAddress(enteredAddressDetailsbeforeSave,addressCountBeforeSave);

		DriverClass.getDriver().quit(); // quit application

	}

}
